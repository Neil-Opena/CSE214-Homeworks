Replace the text file included. Run the class as usual.
Uncomment line 144 to see the actual paths themselves.