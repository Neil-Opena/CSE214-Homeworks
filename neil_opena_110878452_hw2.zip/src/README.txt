Replace the text files included in the folder.
Run the programs as usual. The classes with the main methods are
{FriendList, LeakyStackProgram, TeamSelection, WhiteWalkerProgram}.