Replace the txt files OUTSIDE the src folder.
Run the programs as usual by running the main method inside the FriendList, LeakyStackProgram,
 Team Selection, and WhiteWalkerProgram classes.
