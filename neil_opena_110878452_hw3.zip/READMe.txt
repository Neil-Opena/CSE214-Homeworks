Run the three programs just by calling the class name.
Feel free to use File Redirection or the console.
